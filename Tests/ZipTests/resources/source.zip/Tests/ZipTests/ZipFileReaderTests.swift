import Foundation
import Testing

@testable import Zip

struct ZipFileReaderTests {
    @Test(arguments: ["sample-4", "sample-5", "sample-6", "fakefile_10KB"])
    func loadZip(filename: String) async throws {
        let filePath = Bundle.module.path(forResource: filename, ofType: "zip")!
        let fileHandle = FileHandle(forReadingAtPath: filePath)
        let data = try #require(try fileHandle?.readToEnd())
        let zipFileReader = try await ZipFileReader(ZipFileMemoryStorage(data))
        print(zipFileReader.directory.map { $0.filename })
    }
}
